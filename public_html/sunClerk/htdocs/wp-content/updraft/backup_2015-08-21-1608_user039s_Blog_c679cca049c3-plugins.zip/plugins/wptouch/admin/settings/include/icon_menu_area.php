<?php require_once( WPTOUCH_DIR . '/core/admin-icons.php' ); ?>
<?php require_once( WPTOUCH_DIR . '/core/menu.php' ); 
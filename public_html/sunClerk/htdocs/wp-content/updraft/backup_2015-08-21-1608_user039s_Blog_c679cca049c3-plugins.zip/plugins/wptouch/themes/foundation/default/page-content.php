<div class="<?php wptouch_post_classes(); ?>">
	<div class="post-head-area">
		<h2 class="post-title heading-font"><?php the_title(); ?></h2>
	</div>
	<?php wptouch_the_content() ; ?>
</div>
<div class="wptouch-desktop-switch" style="z-index:1000; padding-top: 10px; padding-bottom: 40px; font-size: 110%; text-align: center; font-weight: bold;">	
	<?php _e( 'Desktop Version', 'wptouch-pro' ); ?> | <a href="<?php wptouch_the_desktop_switch_link(); ?>"><?php _e( 'Switch To Mobile Version', 'wptouch-pro' ); ?></a>
</div>